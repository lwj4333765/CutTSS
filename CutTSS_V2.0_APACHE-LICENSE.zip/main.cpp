/*
* Copyright (c) 2021 Peng Cheng Laboratory.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at:
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

/*-----------------------------------------------------------------------------
 *  
 *  Name:		 Tuple Space Assisted Packet Classification with High Performance on Both Search and Update[1]
 *  Description: Main function of CutTSS, as well as PSTSS[NSDI_2015], PartitionSort[ICNP_2016] and CutSplit[INFOCOM_2018]
 *  Version:	 1.0 (release)
 *  Author:		 Wenjun Li(Peng Cheng Laboratory, Email:wenjunli@pku.edu.cn)	 
 *  Date:		 5/3/2019 
 *  [1] wenjun Li, Tong Yang, Ori Rottenstreich, Xianfeng Li, Gaogang Xie, Hui Li, Balajee Vamanan, Dagang Li and Huiping Lin, “Tuple Space Assisted Packet Classification with High Performance on Both Search and Update,” In Special Issue on Network Softwarization & Enablers，IEEE Journal on Selected Areas in Communications (JSAC), 2020. 
 *-----------------------------------------------------------------------------*/

#include <iostream>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<math.h>
#include<list>
#include <sys/time.h>
#include <string.h>
#include"./CutSplit/CutSplit.h"
#include "./PartitionSort/PartitionSort.h"
#include "./OVS/TupleSpaceSearch.h"
#include "./ElementaryClasses.h"

using namespace std;

FILE *fpr = fopen("./ipc_1k", "r");           // ruleset file
FILE *fpt = fopen("./ipc_1k_trace", "r");           //  trace file 
int classificationFlag = 1; //0:!run classification; 1:run classification 
int updateFlag = 1; //0:!run update; 1:run update (rand_update[MAXRULES]: ~half insert & half delete)

int bucketSize = 8;   // leaf threashold
int ratiotssleaf = 5; //Assume one TSS lookup takes 5 times than one rule linear search  

int threshold = 20;   // For simplity, assume T_SA=T_DA=threshold=20. These values can be chosen dynamicly by running different thresholds 
map<int,int> pri_id;  // rule id <--> rule priority
int rand_update[MAXRULES]; //random generate rule id
int max_pri[4] = {-1,-1,-1,-1}; //the priority of partitioned subsets: priority sorting on subsets

/* 
 * ===  FUNCTION  ======================================================================
 *         Name:  loadrule(FILE *fp)
 *  Description:  load rules from rule file
 * =====================================================================================
 */
vector<Rule> loadrule(FILE *fp)
{
    unsigned int tmp;
    unsigned sip1,sip2,sip3,sip4,smask;
    unsigned dip1,dip2,dip3,dip4,dmask;
    unsigned sport1,sport2;
    unsigned dport1,dport2;
    unsigned protocal,protocol_mask;
    unsigned ht, htmask;
    int number_rule=0; //number of rules

    vector<Rule> rule;

    while(1){

        Rule r;
        std::array<Point,2> points;
        if(fscanf(fp,"@%d.%d.%d.%d/%d\t%d.%d.%d.%d/%d\t%d : %d\t%d : %d\t%x/%x\t%x/%x\n",
                  &sip1, &sip2, &sip3, &sip4, &smask, &dip1, &dip2, &dip3, &dip4, &dmask, &sport1, &sport2,
                  &dport1, &dport2,&protocal, &protocol_mask, &ht, &htmask)!= 18) break;

        if(smask == 0){
            points[0] = 0;
            points[1] = 0xFFFFFFFF;
        }else if(smask > 0 && smask <= 8){
            tmp = sip1<<24;
            points[0] = tmp;
            points[1] = points[0] + (1<<(32-smask)) - 1;
        }else if(smask > 8 && smask <= 16){
            tmp = sip1<<24; tmp += sip2<<16;
            points[0] = tmp;
            points[1] = points[0] + (1<<(32-smask)) - 1;
        }else if(smask > 16 && smask <= 24){
            tmp = sip1<<24; tmp += sip2<<16; tmp +=sip3<<8;
            points[0] = tmp;
            points[1] = points[0] + (1<<(32-smask)) - 1;
        }else if(smask > 24 && smask <= 32){
            tmp = sip1<<24; tmp += sip2<<16; tmp += sip3<<8; tmp += sip4;
            points[0] = tmp;
            points[1] = points[0] + (1<<(32-smask)) - 1;
        }else{
            printf("Src IP length exceeds 32\n");
            exit(-1);
        }
        r.range[0] = points;

        if(dmask == 0){
            points[0] = 0;
            points[1] = 0xFFFFFFFF;
        }else if(dmask > 0 && dmask <= 8){
            tmp = dip1<<24;
            points[0] = tmp;
            points[1] = points[0] + (1<<(32-dmask)) - 1;
        }else if(dmask > 8 && dmask <= 16){
            tmp = dip1<<24; tmp +=dip2<<16;
            points[0] = tmp;
            points[1] = points[0] + (1<<(32-dmask)) - 1;
        }else if(dmask > 16 && dmask <= 24){
            tmp = dip1<<24; tmp +=dip2<<16; tmp+=dip3<<8;
            points[0] = tmp;
            points[1] = points[0] + (1<<(32-dmask)) - 1;
        }else if(dmask > 24 && dmask <= 32){
            tmp = dip1<<24; tmp +=dip2<<16; tmp+=dip3<<8; tmp +=dip4;
            points[0] = tmp;
            points[1] = points[0] + (1<<(32-dmask)) - 1;
        }else{
            printf("Dest IP length exceeds 32\n");
            exit(-1);
        }
        r.range[1] = points;

        points[0] = sport1;
        points[1] = sport2;
        r.range[2] = points;

        points[0] = dport1;
        points[1] = dport2;
        r.range[3] = points;

        if(protocol_mask == 0xFF){
            points[0] = protocal;
            points[1] = protocal;
        }else if(protocol_mask== 0){
            points[0] = 0;
            points[1] = 0xFF;
        }else{
            printf("Protocol mask error\n");
            exit(-1);
        }
        r.range[4] = points;

        r.prefix_length[0] = smask;
        r.prefix_length[1] = dmask;
        r.id = number_rule;
		
        rule.push_back(r);
        number_rule++;
    }

    //printf("the number of rules = %d\n", number_rule);
    int max_pri = number_rule-1;
    for(int i=0;i<number_rule;i++){
        rule[i].priority = max_pri - i;
        pri_id.insert(pair<int,int>(rule[i].priority,rule[i].id));
        /*printf("%u: %u:%u %u:%u %u:%u %u:%u %u:%u %d\n", i,
          rule[i].range[0][0], rule[i].range[0][1],
          rule[i].range[1][0], rule[i].range[1][1],
          rule[i].range[2][0], rule[i].range[2][1],
          rule[i].range[3][0], rule[i].range[3][1],
          rule[i].range[4][0], rule[i].range[4][1],
          rule[i].priority);*/
    }
    pri_id.insert(pair<int,int>(-1,-1));
    return rule;
}

/* 
 * ===  FUNCTION  ======================================================================
 *         Name:  loadpacket(FILE *fp)
 *  Description:  load packets from trace file generated from ClassBench[INFOCOM2005]
 * =====================================================================================
 */
std::vector<Packet> loadpacket(FILE *fp)
{
    unsigned int header[MAXDIMENSIONS];
    unsigned int proto_mask, fid;
    int number_pkt=0; //number of packets
    std::vector<Packet> packets;
    while(1){
        if(fscanf(fp,"%u %u %d %d %d %u %d\n",&header[0], &header[1], &header[2], &header[3], &header[4], &proto_mask, &fid) == Null) break;
        Packet p;
        p.push_back(header[0]);
        p.push_back(header[1]);
        p.push_back(header[2]);
        p.push_back(header[3]);
        p.push_back(header[4]);
        p.push_back(fid);

        packets.push_back(p);
        number_pkt++;
    }
	
    /*printf("the number of packets = %d\n", number_pkt);
    for(int i=0;i<number_pkt;i++){
        printf("%u: %u %u %u %u %u %u\n", i,
               packets[i][0],
               packets[i][1],
               packets[i][2],
               packets[i][3],
               packets[i][4],
               packets[i][5]);
			   }*/
	
    return packets;
}

/* 
 * ===  FUNCTION  ======================================================================
 *         Name:  parseargs(int argc, char *argv[])
 *  Description:  Parse arguments from the console
 * =====================================================================================
 */
void parseargs(int argc, char *argv[])
{
    int	c; 
    bool	ok = 1;
    while ((c = getopt(argc, argv, "b:s:t:r:e:c:u:h")) != -1){
        switch (c) {
            case 'b':  //bucketsize1 of leaf node
                bucketSize = atoi(optarg);
                break;			
            case 't':  //threshold for small fields
                threshold = atoi(optarg);
                break;
            case 'r':  //rule set
                fpr = fopen(optarg, "r");
                break;
            case 'e':  //trace packets for simulations
                fpt = fopen(optarg, "r");
                break;								
            case 'c':  //classification simulation				
				classificationFlag = atoi(optarg);
				break;				
            case 'u':  //update simulation
				updateFlag = atoi(optarg);
                break;
            case 'h': //help
                printf("./main [-b bucketSize][-t threshold(assume T_SA=T_DA)][-r ruleset][-e trace][-c (1:classification)][-u (1:update)]\n");
				printf("e.g., ./main -b 8 -t 20 -r ./ruleset/ipc1_10k -e ./ruleset/ipc1_10k_trace -c 1 -u 1\n");
                printf("mail me: wenjunli@pku.edu.cn\n");
                exit(1);
                break;
            default:
                ok = 0;
        }
    }

    if(bucketSize <= 0 || bucketSize > MAXBUCKETS){
        printf("bucketSize should be greater than 0 and less than %d\n", MAXBUCKETS);
        ok = 0;
    }
    if(threshold < 0 || threshold > 32){
        printf("threshold should be greater than 0 and less than 32\n");
        ok = 0;
    }
    if(fpr == NULL){
        printf("can't open ruleset file\n");
        ok = 0;
    }
	if(classificationFlag != 1 && classificationFlag != 0){
        printf("0:!run classification simulation; 1:run classification simulation\n");
        ok = 0;
    }
	if(updateFlag != 1 && updateFlag != 0){
        printf("0:!run update simulation; 1:run update simulation\n");
        ok = 0;
    }
    if (!ok || optind < argc){
        fprintf (stderr, "./main [-b bucketSize][-t threshold(assume T_SA=T_DA)][-r ruleset][-e trace][-c (1:classification)][-u (1:run update)]\n");
        fprintf (stderr, "Type \"./main -h\" for help\n");
        exit(1);
    }

    printf("************CutTSS: version 1.0 (2019.3.5)******************\n");
    printf("Bucket Size =  %d\n", bucketSize);
    printf("Threshold (T_SA, T_DA) = <2^%d, 2^%d>\n", threshold,threshold);
	printf("Construction: Yes;\tClassification:%s;\tUpdate:%s.\n", (classificationFlag==1?"Yes":"No"),(updateFlag==1?"Yes":"No"));
}


/*
 * ===  FUNCTION  ======================================================================
 *         Name:  count_length (int number_rule,vector<Rule> rule,field_length *field_length_ruleset)
 *  Description:  record length and logarithmic size of rule fields
 * =====================================================================================
 */
int count_length(int number_rule,vector<Rule> rule,field_length *field_length_ruleset,int threshold_value[2])
{
    unsigned temp_size=0;
    unsigned temp_value=0;

    for(int i=0;i<number_rule;i++){ //compute the length and logarithmic size of each rule
        for(int j=0;j<5;j++){  //record field length in field_length_ruleset[i]
            field_length_ruleset[i].length[j]=rule[i].range[j][1]-rule[i].range[j][0];
            if(field_length_ruleset[i].length[j]==0xffffffff)
                field_length_ruleset[i].size[j]=32; //for address *
            else{
				temp_size=0;
                temp_value=field_length_ruleset[i].length[j]+1; 
                while((temp_value=temp_value/2)!=0) temp_size++;               
                if((field_length_ruleset[i].length[j]+1 - pow(2,temp_size))!=0) temp_size++;
                field_length_ruleset[i].size[j]=temp_size;
			}
		}
    }
	
	int num_sa_da = 0;//the number of rules in subset:(small_sa,small_da)
	for(int i=0;i<number_rule;i++)
		if((field_length_ruleset[i].size[0] <= threshold_value[0])&&(field_length_ruleset[i].size[1] <= threshold_value[1]))
			num_sa_da++;
	return 1;	
}


/*
 * ===  FUNCTION  ======================================================================
 *         Name:  partition_v4
 *  Description:  partition ruleset into four subsets based on two address fields (0_sa&da; 1_sa; 2_da; 3_big)
 * =====================================================================================
 */
void partition_v4(vector<Rule> rule,vector<Rule> subset[4],int num_subset[4],int number_rule,field_length *field_length_ruleset,int threshold_value[2])
{  
    int num_small_tmp[number_rule];
    for(int i=0;i<number_rule;i++){ //count the number of small address fields in each rule
        num_small_tmp[i]=0;
		
        for(int k=0;k<2;k++)
            if(field_length_ruleset[i].size[k] <= threshold_value[k])     
                num_small_tmp[i]++;
    }

    int count_sa_da=0; 
    int count_sa=0;    
    int count_da=0;    
    int count_big=0;   
    for(int i=0;i<number_rule;i++){
        if(num_small_tmp[i]==0){
            subset[3].push_back(rule[i]);
            count_big++;
            if(rule[i].priority>max_pri[3]) max_pri[3]=rule[i].priority;
        }
        else if(num_small_tmp[i]==2){
            subset[0].push_back(rule[i]);
            count_sa_da++;
            if(rule[i].priority>max_pri[0]) max_pri[0]=rule[i].priority;
        } //source address (i.e.,sa) and destination address (i.e.,da) are both small fields
        else if(num_small_tmp[i]==1){
            if(field_length_ruleset[i].size[0]<=threshold_value[0]) {
                subset[1].push_back(rule[i]);
                count_sa++;
                if(rule[i].priority>max_pri[1]) max_pri[1]=rule[i].priority;
            }//source address (i.e.,sa) is small
            else if(field_length_ruleset[i].size[1]<=threshold_value[1]){
                subset[2].push_back(rule[i]);
                count_da++;
                if(rule[i].priority>max_pri[2]) max_pri[2]=rule[i].priority;
            } //destination address (i.e.,da) is small

        }
    }

    num_subset[0]=count_sa_da; //#sa_da_subset (sa_small, da_small)
    num_subset[1]=count_sa;    //#sa_subset (sa_small, da_big)
    num_subset[2]=count_da;    //#da_subset (sa_big, da_small)
    num_subset[3]=count_big;   //#big_subset (sa_big, da_big)
	        
    printf("#SA&DA_subset:%d  #SA_subset:%d  #DA_subset:%d  #Big_subset:%d\n\n",count_sa_da,count_sa,count_da,count_big);
} 

/*
 * ===  FUNCTION  ======================================================================
 *         Name:  main function for {CutTSS,PSTSS,PartitionSort,CutSplit}
 *  Description:  loadrule->construction-->classification-->update
 * =====================================================================================
 */
int main(int argc, char* argv[])
{
    parseargs(argc, argv);
    vector<Rule> rule;
    vector<Packet> packets;
	vector<int> results;
	int number_rule = 0;

	std::chrono::time_point<std::chrono::steady_clock> start, end;
    std::chrono::duration<double> elapsed_seconds;
    std::chrono::duration<double,std::milli> elapsed_milliseconds;

    if(fpr != NULL){
        rule = loadrule(fpr);
        number_rule = rule.size();
        printf("The number of rules = %d\n", number_rule);
        field_length *field_length_ruleset = (field_length*)malloc(sizeof(field_length)*number_rule);
        vector<Rule> subset_4[4];  //0_sa & da_small; 1_sa_small & da_big; 2_da_small & sa_big; 3_sa & da_big
        int num_subset_4[4]={0,0,0,0};  //number of rules in each partitioned subset
        int threshold_value[2]={threshold,threshold};   //T_SA = T_DA = threshold 

		count_length(number_rule,rule,field_length_ruleset,threshold_value); 					
		partition_v4(rule,subset_4,num_subset_4,number_rule,field_length_ruleset,threshold_value);

		
        printf("**************** Construction ****************\n");
//---CutTSS---Construction---
        printf("CutTSS\n");
        CutTSS ct_sa_da(3,threshold,subset_4[0],bucketSize,ratiotssleaf);
        CutTSS ct_sa(1,threshold,subset_4[1],bucketSize,ratiotssleaf);
        CutTSS ct_da(2,threshold,subset_4[2],bucketSize,ratiotssleaf);
        PriorityTupleSpaceSearch pstss_big; 		
        //construct classifier
		start = std::chrono::steady_clock::now();
		if(num_subset_4[0] > 0) ct_sa_da.ConstructClassifier(subset_4[0]);
		if(num_subset_4[1] > 0) ct_sa.ConstructClassifier(subset_4[1]);
		if(num_subset_4[2] > 0) ct_da.ConstructClassifier(subset_4[2]);
		if(num_subset_4[3] > 0) pstss_big.ConstructClassifier(subset_4[3]);
		end = std::chrono::steady_clock::now();
		elapsed_milliseconds = end - start;
		printf("\tConstruction time: %f ms\n", elapsed_milliseconds.count());
		ct_sa_da.prints();
        ct_sa.prints();
        ct_da.prints();        
		printf("\n\t***PSTSS for big ruleset:***\n");
		pstss_big.prints();	
							
//---PSTSS---Construction---		
        printf("\nPSTSS\n");
        PriorityTupleSpaceSearch PSTSS;  //Priority Sorting Tuple Space Search (i.e., PSTSS)
        start = std::chrono::steady_clock::now();
        PSTSS.ConstructClassifier(rule); //construct classifier
        end = std::chrono::steady_clock::now();
        elapsed_milliseconds = end - start;
		printf("\tConstruction time: %f ms\n", elapsed_milliseconds.count());		
        PSTSS.prints();
		
//---PartitionSort---Construction---
        printf("\nPartitionSort\n");
        PartitionSort ps;
        start = std::chrono::steady_clock::now();
        ps.ConstructClassifier(rule); //construct classifier
        end = std::chrono::steady_clock::now();
        elapsed_milliseconds = end - start;
        printf("\tConstruction time: %f ms\n", elapsed_milliseconds.count());
		printf("\tTotal memory consumption: %f(KB) \n",double(ps.MemSizeBytes())/1024);
		printf("\tNumber of trees:%d\n",ps.NumTables());							
		
//---CutSplit---Construction---				
		printf("\nCutSplit\n");
		rewind(fpr);
		CutSplit cs(fpr);	

		
        if(classificationFlag != NULL){
            printf("\n**************** Classification ****************\n");
            packets = loadpacket(fpt);
            int number_pkt = packets.size();
            printf("\tThe number of packet in the trace file = %d\n", number_pkt);
            const int trials = 10; //run 10 times circularly
            printf("\tTotal packets (run %d times circularly): %d\n", trials, packets.size()*trials);
			int match_miss = 0;
			
//---CutTSS---Classification---			
            printf("CutTSS\n");
            std::chrono::duration<double> sum_time(0);
            int match_pri = -2;
            int matchid[number_pkt];
			Packet p;			
			match_miss = 0;
			int numtssleafq=0;
							
			for (int t = 0; t < trials; t++) {				
				start = std::chrono::steady_clock::now();
				for(int i=0;i<number_pkt;i++){
					p=packets[i];								
					match_pri = -1;  
					if(num_subset_4[0] > 0) match_pri = ct_sa_da.ClassifyAPacket(p);//Priority sorting, but not absolutely priority sorting for simplity!
					if(match_pri < max_pri[1] && num_subset_4[1] > 0) match_pri = max(match_pri, ct_sa.ClassifyAPacket(p));                  
					if(match_pri < max_pri[2] && num_subset_4[2] > 0) match_pri = max(match_pri, ct_da.ClassifyAPacket(p));   																		
					if(match_pri < max_pri[3] && num_subset_4[3] > 0 && num_subset_4[3] <= ratiotssleaf * pstss_big.NumTables()){						
						for(int i = 0; i < num_subset_4[3]; i++){
							numtssleafq++;
							if(p[0] >= subset_4[3][i].range[0][LowDim] && p[0] <= subset_4[3][i].range[0][HighDim] &&			  
							   p[1] >= subset_4[3][i].range[1][LowDim] && p[1] <= subset_4[3][i].range[1][HighDim] && 			   
							   p[2] >= subset_4[3][i].range[2][LowDim] && p[2] <= subset_4[3][i].range[2][HighDim] &&			   
							   p[3] >= subset_4[3][i].range[3][LowDim] && p[3] <= subset_4[3][i].range[3][HighDim] &&			   
							   p[4] >= subset_4[3][i].range[4][LowDim] && p[4] <= subset_4[3][i].range[4][HighDim]){													
								match_pri = max(match_pri, subset_4[3][i].priority);				
								break;			
							}		
						}																														
					}												
					else if(match_pri < max_pri[3] && num_subset_4[3] > 0) match_pri = max(match_pri, pstss_big.ClassifyAPacket(p));											
					matchid[i] = number_rule-1 - match_pri;                
				}                
				end = std::chrono::steady_clock::now();               
				elapsed_seconds = end - start;				              
				sum_time += elapsed_seconds;		
					
				for(int i = 0;i < number_pkt;i++){					
					if(matchid[i] == -1) match_miss++;					
					else if(packets[i][5] < matchid[i]) match_miss++; // > is correct: match a rule with a higher priority (i.e., smaller rule id)			
				}										           
			}
																											
            printf("\t%d packets are classified, %d of them are misclassified\n", number_pkt * trials, match_miss);				
            printf("\tTotal classification time: %f s\n", sum_time.count() / trials);
			printf("\tAverage classification time: %f us\n", sum_time.count() * 1e6 / (trials * packets.size()));
			printf("\tThroughput: %f Mpps\n", 1 / (sum_time.count() * 1e6 / (trials * packets.size())));											

//---PSTSS---Classification---
            printf("PSTSS\n");
			std::chrono::duration<double> sum_time1(0);	
			results.clear();
			match_miss = 0;
            for (int t = 0; t < trials; t++) {	
                start = std::chrono::steady_clock::now();
				for (auto const &p : packets)
					results.push_back(pri_id[PSTSS.ClassifyAPacket(p)]);			
                end = std::chrono::steady_clock::now();
                elapsed_seconds = end - start;
                sum_time1 += elapsed_seconds;
				for(int i = 0;i < number_pkt;i++){
					if(results[i] == -1) match_miss++;
					else if(packets[i][5] < results[i]) 
						match_miss++;
				}
            }
								
            printf("\t%d packets are classified, %d of them are misclassified\n", number_pkt * trials, match_miss);
			printf("\tTotal classification time: %f s\n", sum_time1.count() / trials);
			printf("\tAverage classification time: %f us\n", sum_time1.count() * 1e6 / (trials * packets.size()));
			printf("\tThroughput: %f Mpps\n", 1 / (sum_time1.count() * 1e6 / (trials * packets.size())));
						
//---PartitionSort---Classification---
            printf("PartitionSort\n");
            std::chrono::duration<double> sum_time2(0);
			match_miss = 0;
			results.clear();
            for (int t = 0; t < trials; t++) {
                start = std::chrono::steady_clock::now();
								
				for (auto const &p : packets)
					results.push_back(pri_id[ps.ClassifyAPacket(p)]);
               				

                end = std::chrono::steady_clock::now();
                elapsed_seconds = end - start;
                sum_time2 += elapsed_seconds;
				for(int i = 0;i < number_pkt;i++)
					if((results[i] == -1) || (packets[i][5] < results[i])) match_miss++;																		                
            }
			
			printf("\t%d packets are classified, %d of them are misclassified\n", number_pkt * trials, match_miss);			
			printf("\tTotal classification time: %f s\n", sum_time2.count() / trials);
			printf("\tAverage classification time: %f us\n", sum_time2.count() * 1e6 / (trials * packets.size()));
			printf("\tThroughput: %f Mpps\n", 1 / (sum_time2.count() * 1e6 / (trials * packets.size())));
					
//---CutSplit---Classification---		
			rewind(fpt);
            printf("CutSplit\n");
            cs.CutSplitTrace(fpt,trials);
        }

		
        if(updateFlag == 1){
            printf("\n**************** Update ****************\n");
            srand((unsigned)time(NULL));
            for(int ra=0;ra<MAXRULES;ra++){ //1000000
                rand_update[ra] = rand()%2; //0:insert 1:delete
            }
            int insert_num = 0, delete_num = 0;
            int number_update = min(number_rule,MAXRULES);
			printf("\tThe number of updated rules = %d\n", number_update);

//---CutTSS---Update---			
            printf("CutTSS\n");
            start = std::chrono::steady_clock::now();
            for(int ra=0;ra<number_update;ra++){
                int smask = rule[ra].prefix_length[0];
                int dmask = rule[ra].prefix_length[1];
				
				//printf("\n---id=%d---\n",ra);
				
                if(rand_update[ra] == 0)//0:insert
                {
					//printf("insert\n");
                    if((smask>=(32-threshold)) && (dmask>=(32-threshold))) ct_sa_da.InsertRule(rule[ra]);
                    else if((smask>=(32-threshold)) && (dmask<(32-threshold))) ct_sa.InsertRule(rule[ra]);
                    else if((smask<(32-threshold)) && (dmask>=(32-threshold))) ct_da.InsertRule(rule[ra]);
                    else if((smask<(32-threshold)) && (dmask<(32-threshold))) pstss_big.InsertRule(rule[ra]);
                    insert_num++;
                } else{//1:delete
					//printf("delete\n");
                    if((smask>=(32-threshold)) && (dmask>=(32-threshold))) ct_sa_da.DeleteRule(rule[ra]);
                    else if((smask>=(32-threshold)) && (dmask<(32-threshold))) ct_sa.DeleteRule(rule[ra]);
                    else if((smask<(32-threshold)) && (dmask>=(32-threshold))) ct_da.DeleteRule(rule[ra]);
                    else if((smask<(32-threshold)) && (dmask<(32-threshold))) pstss_big.DeleteRule(rule[ra]);
                    delete_num++;
                }
            }
            end = std::chrono::steady_clock::now();
            elapsed_seconds = end - start;
            printf("\t%d rules update: insert_num = %d delete_num = %d\n", number_update,insert_num,delete_num);
            printf("\tTotal update time: %f s\n", elapsed_seconds.count());
			printf("\tAverage update time: %f us\n", elapsed_seconds.count()*1e6/number_update);	
			
			

//---PSTSS---Update---			
            printf("PSTSS\n");
            insert_num = 0, delete_num = 0;
            start = std::chrono::steady_clock::now();
            for(int ra=0;ra<number_update;ra++){
                if(rand_update[ra] == 0)//0:insert
                {
                    PSTSS.InsertRule(rule[ra]);
                    insert_num++;
                } else{//1:delete
                    PSTSS.DeleteRule(rule[ra]);
                    delete_num++;
                }
            }
            end = std::chrono::steady_clock::now();
            elapsed_seconds = end - start;
            printf("\t%d rules update: insert_num = %d delete_num = %d\n", number_update,insert_num,delete_num);
            printf("\tTotal update time: %f s\n", elapsed_seconds.count());
			printf("\tAverage update time: %f us\n", elapsed_seconds.count()*1e6/number_update);
				
			
//---PartitionSort---Update--			
			printf("PartitionSort\n");
            insert_num = 0, delete_num = 0;
            start = std::chrono::steady_clock::now();
            for(int ra=0;ra<number_update;ra++){
                if(rand_update[ra] == 0)//0:insert
                {
                    ps.InsertRule(rule[ra]);
                    insert_num++;
                } else{//1:delete
                    ps.DeleteRule1(ra);
                    delete_num++;
                }
            }
            end = std::chrono::steady_clock::now();
            elapsed_seconds = end - start;
            printf("\t%d rules update: insert_num = %d delete_num = %d\n", number_update,insert_num,delete_num);
            printf("\tTotal update time: %f s\n", elapsed_seconds.count());
            printf("\tAverage update time: %f us\n", elapsed_seconds.count()*1e6/number_update);	
						
        }

    }
	
    printf("\n**************** Over ****************\n");
    return 0;

}


