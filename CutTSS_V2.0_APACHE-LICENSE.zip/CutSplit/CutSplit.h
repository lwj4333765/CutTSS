/*
* Copyright (c) 2021 Peng Cheng Laboratory.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at:
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

#pragma once
#ifndef  _CUTSPLIT_H
#define  _CUTSPLIT_H


#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<math.h>
#include<list>
#include"trie.h"
#include <sys/time.h>

class CutSplit{
private:
int total_query;
int bucketSize;
int threshold;
pc_rule *rule;
int number_rule;
pc_rule* subset_4[4];
int num_subset_4[4];
int threshold_value[2];

trie T_sa;
trie T_sa_da;
trie T_da;
hs_node_t* big_node;
hstrie T;



public:
CutSplit(FILE* fpr);
int loadrule1(FILE *fp,pc_rule *rule);
void count_length1(int number_rule,pc_rule *rule,field_length *field_length_ruleset);
void partition_V2(pc_rule *rule,pc_rule* subset[3],int num_subset[3],int number_rule,field_length *field_length_ruleset,int threshold_value[2]);
void partition_V3(pc_rule *rule,pc_rule* subset[4],int num_subset[4],int number_rule,field_length *field_length_ruleset,int threshold_value[2]);
void CutSplitTrace(FILE* fpt,int trials);

};

#endif 
