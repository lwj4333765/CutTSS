/*
* Copyright (c) 2021 Peng Cheng Laboratory.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at:
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/


/*-----------------------------------------------------------------------------
 *  
 *  Name:		CutSplit: A Decision-Tree Combining Cutting and Splitting for Scalable Packet Classification[2]
 *  Version:	1.0 (release)
 *  Author:		Wenjun Li(Peng Cheng Laboratory, Email:wenjunli@pku.edu.cn)	 
 *  Date:		15/3/2019
 *  [2]Wenjun Li, Xianfeng Li, Hui Li and Gaogang Xie, “CutSplit: A Decision-Tree Combining Cutting and Splitting for Scalable Packet Classification,” In IEEE International Conference on Computer Communications (INFOCOM), 2018. 
 *-----------------------------------------------------------------------------*/


#include "CutSplit.h"
 
/* 
 * ===  FUNCTION  ======================================================================
 *         Name:  loadrule
 *  Description:  load rules from file
 * =====================================================================================
 */
int CutSplit::loadrule1(FILE *fp,pc_rule *rule)
{
   int tmp;
   unsigned sip1,sip2,sip3,sip4,smask;
   unsigned dip1,dip2,dip3,dip4,dmask;
   unsigned sport1,sport2;
   unsigned dport1,dport2;
   unsigned protocal,protocol_mask;
   unsigned ht, htmask;
   int number_rule=0; //number of rules

   while(1){
      if(fscanf(fp,"@%d.%d.%d.%d/%d\t%d.%d.%d.%d/%d\t%d : %d\t%d : %d\t%x/%x\t%x/%x\n",
                &sip1, &sip2, &sip3, &sip4, &smask, &dip1, &dip2, &dip3, &dip4, &dmask, &rule[number_rule].field[2].low, &rule[number_rule].field[2].high,
                &rule[number_rule].field[3].low, &rule[number_rule].field[3].high,&protocal, &protocol_mask, &ht, &htmask)!= 18) break;


   if(smask == 0){
      rule[number_rule].field[0].low = 0;
      rule[number_rule].field[0].high = 0xFFFFFFFF;
    }else if(smask > 0 && smask <= 8){
      tmp = sip1<<24;
      rule[number_rule].field[0].low = tmp;
      rule[number_rule].field[0].high = rule[number_rule].field[0].low + (1<<(32-smask)) - 1;
    }else if(smask > 8 && smask <= 16){
      tmp = sip1<<24; tmp += sip2<<16;
      rule[number_rule].field[0].low = tmp; 	
      rule[number_rule].field[0].high = rule[number_rule].field[0].low + (1<<(32-smask)) - 1;	
    }else if(smask > 16 && smask <= 24){
      tmp = sip1<<24; tmp += sip2<<16; tmp +=sip3<<8; 
      rule[number_rule].field[0].low = tmp; 	
      rule[number_rule].field[0].high = rule[number_rule].field[0].low + (1<<(32-smask)) - 1;			
    }else if(smask > 24 && smask <= 32){
      tmp = sip1<<24; tmp += sip2<<16; tmp += sip3<<8; tmp += sip4;
      rule[number_rule].field[0].low = tmp; 
      rule[number_rule].field[0].high = rule[number_rule].field[0].low + (1<<(32-smask)) - 1;	
    }else{
      printf("Src IP length exceeds 32\n");
      return 0;
    }
    if(dmask == 0){
      rule[number_rule].field[1].low = 0;
      rule[number_rule].field[1].high = 0xFFFFFFFF;
    }else if(dmask > 0 && dmask <= 8){
      tmp = dip1<<24;
      rule[number_rule].field[1].low = tmp;
      rule[number_rule].field[1].high = rule[number_rule].field[1].low + (1<<(32-dmask)) - 1;
    }else if(dmask > 8 && dmask <= 16){
      tmp = dip1<<24; tmp +=dip2<<16;
      rule[number_rule].field[1].low = tmp; 	
      rule[number_rule].field[1].high = rule[number_rule].field[1].low + (1<<(32-dmask)) - 1;	
    }else if(dmask > 16 && dmask <= 24){
      tmp = dip1<<24; tmp +=dip2<<16; tmp+=dip3<<8;
      rule[number_rule].field[1].low = tmp; 	
      rule[number_rule].field[1].high = rule[number_rule].field[1].low + (1<<(32-dmask)) - 1;			
    }else if(dmask > 24 && dmask <= 32){
      tmp = dip1<<24; tmp +=dip2<<16; tmp+=dip3<<8; tmp +=dip4;
      rule[number_rule].field[1].low = tmp; 	
      rule[number_rule].field[1].high = rule[number_rule].field[1].low + (1<<(32-dmask)) - 1;	
    }else{
      printf("Dest IP length exceeds 32\n");
      return 0;
    }
    if(protocol_mask == 0xFF){
      rule[number_rule].field[4].low = protocal;
      rule[number_rule].field[4].high = protocal;
    }else if(protocol_mask== 0){
      rule[number_rule].field[4].low = 0;
      rule[number_rule].field[4].high = 0xFF;
    }else{
      printf("Protocol mask error\n");
      return 0;
    }

       rule[number_rule].id = number_rule;
       number_rule++;
   }
  
   /* 
   printf("the number of rules = %d\n", number_rule);
     for(int i=0;i<number_rule;i++){
      printf("%u: %u:%u %u:%u %u:%u %u:%u %u:%u\n", i,
        rule[i].field[0].low, rule[i].field[0].high, 
        rule[i].field[1].low, rule[i].field[1].high,
        rule[i].field[2].low, rule[i].field[2].high,
        rule[i].field[3].low, rule[i].field[3].high, 
        rule[i].field[4].low, rule[i].field[4].high);}
   */

  return number_rule;  
}


/* 
 * ===  FUNCTION  ======================================================================
 *         Name:  count_length
 *  Description:  record length of field and correponding size
 * =====================================================================================
 */
void CutSplit::count_length1(int number_rule,pc_rule *rule,field_length *field_length_ruleset)
{
   unsigned temp_size=0;
   unsigned temp_value=0;
 
   for(int i=0;i<number_rule;i++) 
   {
       for(int j=0;j<5;j++)  //record field length in field_length_ruleset[i]
       {
          field_length_ruleset[i].length[j]=rule[i].field[j].high-rule[i].field[j].low;    
          if(field_length_ruleset[i].length[j]==0xffffffff)
             field_length_ruleset[i].size[j]=32; //for address *
          else 
          {
             temp_size=0;
             temp_value=field_length_ruleset[i].length[j]+1;   
             while((temp_value=temp_value/2)!=0)
                temp_size++;  
             if((field_length_ruleset[i].length[j]+1 - pow(2,temp_size))!=0) 
               temp_size++; 

             field_length_ruleset[i].size[j]=temp_size;
          }
       }
   }
}




/*
 * ===  FUNCTION  ======================================================================
 *         Name:  partition_v3 (version3)
 *  Description:  partition ruleset into subsets based on address field(2 dim.)
 * =====================================================================================
 */
void CutSplit::partition_V3(pc_rule *rule,pc_rule* subset[4],int num_subset[4],int number_rule,field_length *field_length_ruleset,int threshold_value[2])
{  // 0:sa,da; 1:sa; 2:da; 3:big
    int num_small_tmp[number_rule];
    for(int i=0;i<number_rule;i++){ 
        num_small_tmp[i]=0;
        for(int k=0;k<2;k++)
            if(field_length_ruleset[i].size[k] <= threshold_value[k])
                num_small_tmp[i]++;
    }

    int count_sa_da=0;
    int count_sa=0;
    int count_da=0;
    int count_big=0;   
    for(int i=0;i<number_rule;i++){
        if(num_small_tmp[i]==0)
            subset[3][count_big++]=rule[i];
        else if(num_small_tmp[i]==2)
            subset[0][count_sa_da++]=rule[i];
        else if(num_small_tmp[i]==1){
            if(field_length_ruleset[i].size[0]<=threshold_value[0]) //sip:small
                subset[1][count_sa++]=rule[i];
            else if(field_length_ruleset[i].size[1]<=threshold_value[1]) //dip:small
                subset[2][count_da++]=rule[i];
        }
    }

    num_subset[0]=count_sa_da;
    num_subset[1]=count_sa;
    num_subset[2]=count_da;
    num_subset[3]=count_big;

	printf("\t#SA&DA_subset:%d  #SA_subset:%d  #DA_subset:%d  #Big_subset:%d\n\n",count_sa_da,count_sa,count_da,count_big);

}


CutSplit::CutSplit(FILE* fpr)
{
    bucketSize = 8;   // leaf threashold
    threshold = 16;   // Assume T_SA=T_DA=threshold
	
	printf("\tBucket Size =  %d\n", bucketSize);
    printf("\tThreshold (T_SA, T_DA) = <2^%d, 2^%d>\n", threshold,threshold);
	
    std::chrono::time_point<std::chrono::steady_clock> start, end;
    std::chrono::duration<double> elapsed_seconds;
    std::chrono::duration<double,std::milli> elapsed_milliseconds;

    number_rule=0;
    char test1;
    while((test1=fgetc(fpr))!=EOF)
        if(test1=='@')
            number_rule++;
    rewind(fpr);
    rule = (pc_rule *)calloc(number_rule, sizeof(pc_rule));
    number_rule=loadrule1(fpr,rule);
    fclose(fpr);
 
    field_length field_length_ruleset[number_rule];
    count_length1(number_rule,rule,field_length_ruleset); 

    for(int n=0;n<4;n++)
        subset_4[n]=(pc_rule *)malloc(number_rule*sizeof(pc_rule));
    num_subset_4[0]=0;num_subset_4[1]=0;num_subset_4[2]=0;num_subset_4[3]=0;
    threshold_value[0]=threshold;threshold_value[1]=threshold;   //T_SA=T_DA=threshold 

    partition_V3(rule,subset_4,num_subset_4,number_rule,field_length_ruleset,threshold_value); 

 

    start = std::chrono::steady_clock::now();
    //construct classifier
    T_sa_da.trie1(num_subset_4[0],bucketSize,rule,subset_4[0],threshold,3); 
    T_sa.trie1(num_subset_4[1],bucketSize,rule,subset_4[1],threshold,1); 
    T_da.trie1(num_subset_4[2],bucketSize,rule,subset_4[2],threshold,2); 
    big_node = (hs_node_t *) malloc(sizeof(hs_node_t));
    if(num_subset_4[3] > 0){  
        T.hstrie1(num_subset_4[3],subset_4[3], bucketSize, big_node);
    }
    end = std::chrono::steady_clock::now();
    elapsed_milliseconds = end - start;

    if(num_subset_4[3] > 0){ 
     printf("\t***Big Subset Tree(using HyperSplit):***\n");
     printf("\tRESULTS:");
     printf("\n\tnumber of rules:%d",num_subset_4[3]);
     printf("\n\tTotal memory consumption: %f(KB) \n", T.result.total_mem_kb);
    }
    printf("\n\tConstruction time: %f ms\n", elapsed_milliseconds.count());
}




void CutSplit::CutSplitTrace(FILE* fpt,int trials)
{
    int header[MAXDIMENSIONS];
    int match_sa_da, match_sa, match_da, match_big, fid;
    int matchid;
	struct timespec startin, endout;
    unsigned int long delta_time = 0;
	
	int match_miss = 0;
	int match_pri = -2;
	
	std::chrono::time_point<std::chrono::steady_clock> start, end;
    std::chrono::duration<double> elapsed_seconds;
    std::chrono::duration<double,std::milli> elapsed_milliseconds;


    unsigned int proto_mask;
    int mem_acc[1] = {0};
    if(fpt != NULL){
        int i=0, j=0;
		int number_pkt=0;
		
		std::vector<Packet> packets;
		while(fscanf(fpt,"%u %u %d %d %d %u %d\n",
                     &header[0], &header[1], &header[2], &header[3], &header[4], &proto_mask, &fid) != Null){	
			Packet p;
			p.push_back(header[0]);       
			p.push_back(header[1]);       
			p.push_back(header[2]);      
			p.push_back(header[3]);       
			p.push_back(header[4]);        
			p.push_back(fid);
        
			packets.push_back(p);
			number_pkt++;	
		}
		
		
		
		std::chrono::duration<double> sum_time(0);
		start = std::chrono::steady_clock::now();

		for (int t = 0; t < trials; t++) {
		
		
		for(int i=0;i<number_pkt;i++){
						
			int header1[MAXDIMENSIONS]={packets[i][0],packets[i][1],packets[i][2],packets[i][3],packets[i][4]};
			
			matchid = match_sa_da = match_sa = match_da = match_big = -1;
			
			match_sa_da = T_sa_da.trieLookup(header1);
            match_sa = T_sa.trieLookup(header1);
            match_da = T_da.trieLookup(header1);
            if(num_subset_4[3] > 0) match_big = LookupHSTree(rule,big_node,header1,mem_acc);
			
			if(match_sa_da != -1) matchid = match_sa_da;
            if((matchid == -1) || (match_sa != -1 && match_sa < matchid)) matchid = match_sa;
            if((matchid == -1) || (match_da != -1 && match_da < matchid)) matchid = match_da;
            if((matchid == -1) || (match_big != -1 && match_big < matchid)) matchid = match_big;		
			            
			if(matchid == -1){
                printf("? packet %d match NO rule, should be %d\n", i, packets[i][5]);
				match_miss++;
              
            }else if(matchid == packets[i][5]){
                //printf("\nmatch_id = %d   fid = %d   -----   packet %d match rule %d\n", matchid, packets[i][5], i, matchid);
            }else if(matchid > packets[i][5]){
                printf("? packet %d match lower priority rule %d, should be %d\n", i, matchid, packets[i][5]);
                match_miss++;
            }else{
                //printf("! packet %d match higher priority rule %d, should be %d\n", i, matchid, packets[i][5]);
			}
			
		}
							
		}
		
		end = std::chrono::steady_clock::now();
		elapsed_seconds = end - start;
		sum_time += elapsed_seconds;
		
										
        printf("\t%d packets are classified, %d of them are misclassified\n", number_pkt * trials, match_miss);
		printf("\tTotal classification time: %f s\n", sum_time.count() / trials);
		printf("\tAverage classification time: %f us\n", sum_time.count() * 1e6 / (trials * packets.size()));
		printf("\tThroughput: %f Mpps\n", 1 / (sum_time.count() * 1e6 / (trials * packets.size())));
		
 
    }else{
        printf("\nNo packet trace input\n");
    }

    free(rule);free(big_node);
    for(int n=0;n<4;n++)
        free(subset_4[n]);

}


