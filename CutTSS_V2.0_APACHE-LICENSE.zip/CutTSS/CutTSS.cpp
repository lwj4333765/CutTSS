/*
* Copyright (c) 2021 Peng Cheng Laboratory.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at:
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

/*-----------------------------------------------------------------------------
 *  
 *  Name:		 Tuple Space Assisted Packet Classification with High Performance on Both Search and Update[1]
 *  Version:	 1.0 (release)
 *  Author:		 Wenjun Li(Peng Cheng Laboratory, Email:wenjunli@pku.edu.cn)	 
 *  Date:		 5/3/2019 
 *  [1] wenjun Li, Tong Yang, Ori Rottenstreich, Xianfeng Li, Gaogang Xie, Hui Li, Balajee Vamanan, Dagang Li and Huiping Lin, “Tuple Space Assisted Packet Classification with High Performance on Both Search and Update,” In Special Issue on Network Softwarization & Enablers，IEEE Journal on Selected Areas in Communications (JSAC), 2020.
 *-----------------------------------------------------------------------------
 */

#include "CutTSS.h"
using namespace std;

CutTSS::CutTSS(int k1, int threshold1, std::vector<Rule>& classifier,int bucketSize, int ratiotssleaf){
	k=k1;      //01:SA, 10:DA, 11:SA&DA
	speedUpFlag = k1;
	binth=bucketSize;
 
	rtssleaf = ratiotssleaf;
	threshold = pow(2,threshold1);  
	for (int i=0; i<MAXDIMENSIONS; i++){
		dim[i] = 0;
		if((k & (1 << i)) > 0) dim[i] = 1;
	}
    this->rules = classifier;
	numrules = classifier.size();
	nodeSet = new CutTSSNode[MAXNODES+1];
	root = 1;

	pass=1;
	Total_Rule_Size=0;
	Total_Array_Size=0;
	Leaf_Node_Count=0;
	NonLeaf_Node_Count=0;
	Total_Tuple_Count=0;
	total_ficuts_memory_in_KB=0;
	total_tss_memory_in_KB=0;
	total_memory_in_KB=0;

	for(int i=1; i<=MAXNODES; i++) {
		nodeSet[i].child = (int*)malloc(sizeof(int));
		nodeSet[i].ntuples = 0;		
	}

	nodeSet[root].isleaf = 0;
	nodeSet[root].nrules = numrules;


	for (int i=0; i<MAXDIMENSIONS; i++){
		nodeSet[root].field[i].low = 0;
		if(i<2)
			nodeSet[root].field[i].high = 0xffffffff;
		else if(i==4)
			nodeSet[root].field[i].high = 255;
		else
			nodeSet[root].field[i].high = 65535;

		nodeSet[root].ncuts[i] = 1;
	}

	nodeSet[root].classifier = classifier;

	nodeSet[root].depth = 1; 
	nodeSet[root].flag = 1; //cut
	nodeSet[root].ntuples = 0;

	freelist = 2; 
}

CutTSS::~CutTSS() {
	delete [] nodeSet;
}



//cut on SA or DA field
void CalcCuts1(CutTSSNode* node, int dim[MAXDIMENSIONS], int threshold){
	int done=0;
	int sum=0;
	int numcut=0;
	int lo,hi,r; 
	int nbits;

	for(int i=0;i<MAXDIMENSIONS;i++){
		node->ncuts[i] = 1;
		if(dim[i]){ 
			done = 0;			
			while(!done){
				sum=0;
				for(int j=0; j<node->nrules; j++){
					r = (node->field[i].high - node->field[i].low)/node->ncuts[i];
					lo = node->field[i].low;
					hi = lo + r;
					for(int k=0; k<node->ncuts[i]; k++){
						if((node->classifier[j].range[i][LowDim]>=lo && node->classifier[j].range[i][LowDim]<=hi)||
						   (node->classifier[j].range[i][HighDim]>=lo && node->classifier[j].range[i][HighDim]<=hi)||
						   (node->classifier[j].range[i][LowDim]<=lo && node->classifier[j].range[i][HighDim]>=hi))
							sum++;
						lo = hi + 1;
						hi = lo + r;												
					}
				}
			
				if(sum != node->nrules){
					node->ncuts[i] = max(node->ncuts[i]/2,1);
					done=1;					
					node->numbit[i] = int(log(node->ncuts[i])/log(2));					
					node->andbit[i] = (1<<int(log(node->ncuts[i])/log(2)))-1;		
					 
				}					
				else if((node->ncuts[i] <= MAXCUTS1/2) && (node->ncuts[i] < (node->field[i].high - node->field[i].low)/2)) 
				//if(node->ncuts[i] < MAXCUTS1 && (node->field[i].high - node->field[i].low) > threshold) //basic
					node->ncuts[i] = node->ncuts[i]*2;
				else{
					done=1;
					node->numbit[i] = int(log(node->ncuts[i])/log(2));
					node->andbit[i] = (1<<int(log(node->ncuts[i])/log(2)))-1;
				}
			}
			
		}
	}
}


//cut on SA & DA fields
void CalcCuts2(CutTSSNode* node, int dim[MAXDIMENSIONS], int threshold){
	int done=0;
	int sum=0;
	int numcut=0;
	int lo,hi,r; 

	for(int i=0;i<MAXDIMENSIONS;i++){
		node->ncuts[i] = 1;
		if(dim[i]){ 
			done = 0;			
			while(!done){
				sum=0;
				for(int j=0; j<node->nrules; j++){
					r = (node->field[i].high - node->field[i].low)/node->ncuts[i];
					lo = node->field[i].low;
					hi = lo + r;
					for(int k=0; k<node->ncuts[i]; k++){
						if((node->classifier[j].range[i][LowDim]>=lo && node->classifier[j].range[i][LowDim]<=hi)||
						   (node->classifier[j].range[i][HighDim]>=lo && node->classifier[j].range[i][HighDim]<=hi)||
						   (node->classifier[j].range[i][LowDim]<=lo && node->classifier[j].range[i][HighDim]>=hi))
							sum++;
						lo = hi + 1;
						hi = lo + r;												
					}
				}
								
				
				if(sum != node->nrules){
					node->ncuts[i] = max(node->ncuts[i]/2,1);
					done=1;
					node->numbit[i] = int(log(node->ncuts[i])/log(2));
					node->andbit[i] = (1<<int(log(node->ncuts[i])/log(2)))-1;
				}					
				else if((node->ncuts[i] <= MAXCUTS2/2) && (node->ncuts[i] < (node->field[i].high - node->field[i].low)/2)) 
				//if(node->ncuts[i] < MAXCUTS1 && (node->field[i].high - node->field[i].low) > threshold) //basic
					node->ncuts[i] = node->ncuts[i]*2;
				else{
					done=1;
					node->numbit[i] = int(log(node->ncuts[i])/log(2));
					node->andbit[i] = (1<<int(log(node->ncuts[i])/log(2)))-1;		
				}
				

			}
			
		}
	}
}



void CutTSS::ConstructClassifier(const vector<Rule>& rules)
{
	int nr;
	int empty;
	unsigned int r[MAXDIMENSIONS], lo[MAXDIMENSIONS], hi[MAXDIMENSIONS];
	int u,v;
	int s = 0;
	int i[MAXDIMENSIONS];
	int flag,index;
	
	int num_leaf_rule = 0;
	int num_tss_rule = 0;

	qNode.push(root);

	while(!qNode.empty()){
		v=qNode.front();
		qNode.pop();

		if(nodeSet[v].flag==1){
			if(k==3){  //cut on subset with two small address fields: SA & DA			
				CalcCuts2(&nodeSet[v],dim,threshold);  
				for(int t=0;t<MAXDIMENSIONS;t++){					
					if(dim[t]){	
						if(nodeSet[v].ncuts[t] < MAXCUTS2) //finish Pre-cuttings, tranfer to Post-TSS
							nodeSet[v].flag=2;  //tss		
					}
				}
			} else{ //cut on subset with one small address field: SA or DA
				CalcCuts1(&nodeSet[v],dim,threshold);  
				for(int t=0;t<MAXDIMENSIONS;t++){
					if(dim[t]){
						if(nodeSet[v].ncuts[t] < MAXCUTS1) //finish Pre-cuttings, tranfer to Post-TSS
							nodeSet[v].flag=2;  //tss
					}
				}												
			}
		}
		
		if(nodeSet[v].flag==1){ //Pre-Cutting stage: FiCuts
			if(nodeSet[v].nrules <= binth){ //leaf nodes
				num_leaf_rule += nodeSet[v].nrules;
				nodeSet[v].isleaf = 1;
				Total_Rule_Size+= nodeSet[v].nrules;
				Leaf_Node_Count++;
			}
			else{  
				NonLeaf_Node_Count++;
				nodeSet[v].child = (int *)realloc(nodeSet[v].child, nodeSet[v].ncuts[0] * nodeSet[v].ncuts[1] * sizeof(int));

				Total_Array_Size += (nodeSet[v].ncuts[0] * nodeSet[v].ncuts[1]);
				index = 0;

				r[0] = (nodeSet[v].field[0].high - nodeSet[v].field[0].low)/nodeSet[v].ncuts[0]; 
				lo[0] = nodeSet[v].field[0].low;
				hi[0] = lo[0] + r[0];
				for(i[0] = 0; i[0] < nodeSet[v].ncuts[0]; i[0]++){  //sip

					r[1] = (nodeSet[v].field[1].high - nodeSet[v].field[1].low)/nodeSet[v].ncuts[1];
					lo[1] = nodeSet[v].field[1].low;
					hi[1] = lo[1] + r[1];
					for(i[1] = 0; i[1] < nodeSet[v].ncuts[1]; i[1]++){ //dip

						r[2] = (nodeSet[v].field[2].high - nodeSet[v].field[2].low)/nodeSet[v].ncuts[2];
						lo[2] = nodeSet[v].field[2].low;
						hi[2] = lo[2] + r[2];
						for(i[2] = 0; i[2] < nodeSet[v].ncuts[2]; i[2]++){ 

							r[3] = (nodeSet[v].field[3].high - nodeSet[v].field[3].low)/nodeSet[v].ncuts[3];
							lo[3] = nodeSet[v].field[3].low;
							hi[3] = lo[3] + r[3];
							for(i[3] = 0; i[3] < nodeSet[v].ncuts[3]; i[3]++){ 

								r[4] = (nodeSet[v].field[4].high - nodeSet[v].field[4].low)/nodeSet[v].ncuts[4];
								lo[4] = nodeSet[v].field[4].low;
								hi[4] = lo[4] + r[4];
								for(i[4] = 0; i[4] < nodeSet[v].ncuts[4]; i[4]++){ 

									empty = 1;
									nr = 0;
									for (const Rule r : nodeSet[v].classifier) {
										flag = 1;
										for(int t = 0; t < MAXDIMENSIONS; t++){
											if(r.range[t][0] > hi[t] || r.range[t][1] < lo[t]){
												flag = 0;
												break;
											}
										}
										if(flag == 1){
											empty = 0;
											nr++;
										}
									}

									if(!empty){
										nodeSet[v].child[index] = freelist;
										u=freelist;
										freelist++;//next node
										nodeSet[u].nrules = nr;
										nodeSet[u].depth=nodeSet[v].depth+1;
										if(nr <= binth){ //leaf node
											num_leaf_rule += nr;
											nodeSet[u].isleaf = 1;
											Total_Rule_Size+= nr;
											Leaf_Node_Count++;
										}
										else{
											nodeSet[u].isleaf = 0;
											nodeSet[u].flag=1;  //cut

											if(pass<nodeSet[u].depth){
												pass=nodeSet[u].depth;
											}

											qNode.push(u);  
										}

										for (int t=0; t<MAXDIMENSIONS; t++){   //update node ranges
											if(dim[t] == 1){
												nodeSet[u].field[t].low = lo[t];
												nodeSet[u].field[t].high= hi[t];
											}else{
												nodeSet[u].field[t].low = nodeSet[v].field[t].low;
												nodeSet[u].field[t].high= nodeSet[v].field[t].high;
											}
										}

										//update rules in node
										for (const Rule r : nodeSet[v].classifier) {
											flag = 1;
											for(int t = 0; t < MAXDIMENSIONS; t++){
												if(r.range[t][0] > hi[t] || r.range[t][1] < lo[t]){
													flag = 0;
													break;
												}
											}
											if(flag == 1){
												nodeSet[u].classifier.push_back(r);
											}
										}

									}
									else //empty
										nodeSet[v].child[index] = Null;

									index ++;

									lo[4] = hi[4] + 1;    
									hi[4] = lo[4] + r[4];
								}
								lo[3] = hi[3] + 1;
								hi[3] = lo[3] + r[3];
							}
							lo[2] = hi[2] + 1;
							hi[2] = lo[2] + r[2];
						}
						lo[1] = hi[1] + 1;
						hi[1] = lo[1] + r[1];
					}
					lo[0] = hi[0] + 1;
					hi[0] = lo[0] + r[0];
				}
			}
		} else{ //TSS search or TSS leaf node stage							
			PriorityTupleSpaceSearch ptmp;
			ptmp.ConstructClassifier(nodeSet[v].classifier);
			int numtuple1 = ptmp.NumTables(); 			
			if(nodeSet[v].nrules <= (rtssleaf * numtuple1)){  //with optimization on terminal leaf nodes			
			//if(nodeSet[v].nrules <= binth){  //without optimization on terminal leaf nodes			
				num_leaf_rule += nodeSet[v].nrules;
				nodeSet[v].isleaf = 1;
				Total_Rule_Size+= nodeSet[v].nrules;
				Leaf_Node_Count++;
			}
			else{ //None-leaf terminal nodes
				NonLeaf_Node_Count++;
				num_tss_rule += nodeSet[v].nrules;
				nodeSet[v].PSTSS.ConstructClassifier(nodeSet[v].classifier);
				nodeSet[v].ntuples = nodeSet[v].PSTSS.NumTables();							
				nodeSet[v].depth += nodeSet[v].ntuples; 
				Total_Tuple_Count += nodeSet[v].ntuples;
				total_tss_memory_in_KB += nodeSet[v].PSTSS.MemSizeBytes();
			}
		}
	}
	
//printf("\tnum_leaf_rule = %d, num_tss_rule=%d\n",num_leaf_rule,num_tss_rule);			
}

 
int CutTSS::ClassifyAPacket(const Packet &packet){

	int cnode = 1;
	int flag_tss = 0;
	int match_id = -1;	
	unsigned int cchild = 0;
	unsigned int numbit = 32;
	unsigned int numbit1 = 32;
	unsigned int numbit2 = 32;


 
	switch(speedUpFlag){ // speedUpFlag=3:sa&da,1:sa, 2:da, others:for !5-tuple rules	
		case 1:{
			while(nodeSet[cnode].isleaf != 1){  //find matched leaf nodes: cnode
				numbit -= nodeSet[cnode].numbit[0];
				cchild = (packet[0]>>numbit) & nodeSet[cnode].andbit[0];	
				cnode = nodeSet[cnode].child[cchild];  //level++
				queryCount[0]++;
				
				if(cnode == Null) break;
				if(nodeSet[cnode].flag == 2 && nodeSet[cnode].isleaf != 1) {
					flag_tss = 1;
					break;
				}					
			}
			break;
		}
		case 2:{
			while(nodeSet[cnode].isleaf != 1){  //find matched leaf nodes: cnode
				numbit -= nodeSet[cnode].numbit[1];
				cchild = (packet[1]>>numbit) & nodeSet[cnode].andbit[1];
				cnode = nodeSet[cnode].child[cchild];   
				queryCount[0]++;
				
				if(cnode == Null) break;
				if(nodeSet[cnode].flag == 2 && nodeSet[cnode].isleaf != 1) {
					flag_tss = 1;
					break;
				}					
			}
			break;			
		}
		case 3:{
			while(nodeSet[cnode].isleaf != 1){   //find matched leaf nodes: cnode
				numbit1 -= nodeSet[cnode].numbit[0];
				numbit2 -= nodeSet[cnode].numbit[1];
				cchild = ((packet[0]>>numbit1) & nodeSet[cnode].andbit[0])*nodeSet[cnode].ncuts[1] + ((packet[1]>>numbit2) & nodeSet[cnode].andbit[1]);
				cnode = nodeSet[cnode].child[cchild];  
				queryCount[0]++;
				if(cnode == Null) break;
				if(nodeSet[cnode].flag == 2 && nodeSet[cnode].isleaf != 1) {
					flag_tss = 1;
					break;
				}							
			}
			break;		
		}
		default: break;
			
	}

	if(cnode != Null && flag_tss == 1){ //tss stage: PSTSS
		match_id = nodeSet[cnode].PSTSS.ClassifyAPacket(packet); //priority
	}
	else if(cnode != Null && flag_tss == 0 && nodeSet[cnode].isleaf == 1){ //cut stage: linear search
		for(int i = 0; i < nodeSet[cnode].nrules; i++){
			queryCount[0]++;
			if(packet[0] >= nodeSet[cnode].classifier[i].range[0][LowDim] && packet[0] <= nodeSet[cnode].classifier[i].range[0][HighDim] &&
			   packet[1] >= nodeSet[cnode].classifier[i].range[1][LowDim] && packet[1] <= nodeSet[cnode].classifier[i].range[1][HighDim] && 
			   packet[2] >= nodeSet[cnode].classifier[i].range[2][LowDim] && packet[2] <= nodeSet[cnode].classifier[i].range[2][HighDim] &&
			   packet[3] >= nodeSet[cnode].classifier[i].range[3][LowDim] && packet[3] <= nodeSet[cnode].classifier[i].range[3][HighDim] &&
			   packet[4] >= nodeSet[cnode].classifier[i].range[4][LowDim] && packet[4] <= nodeSet[cnode].classifier[i].range[4][HighDim]){
				match_id = nodeSet[cnode].classifier[i].priority;
				break;
			}
		}		
	}
	
	return  match_id;	
}



void CutTSS::DeleteRule(const Rule& delete_rule) {
	int cchild;
	int cnode = 1;
	int i,j;
	int flag_tss = 0;
	
	unsigned int numbit = 32;
	unsigned int numbit1 = 32;
	unsigned int numbit2 = 32;

	switch(speedUpFlag) // speedUpFlag=3:sa&da,1:sa, 2:da, others:for !5-tuple rules
	{		
		case 1:{
			while(nodeSet[cnode].isleaf != 1){   //find matched leaf nodes: cnode
				numbit -= nodeSet[cnode].numbit[0];
				cchild = (delete_rule.range[0][0]>>numbit) & nodeSet[cnode].andbit[0];	
				cnode = nodeSet[cnode].child[cchild];  
				queryCount[0]++;
				
				if(cnode == Null) break;
				if(nodeSet[cnode].flag == 2 && nodeSet[cnode].isleaf != 1) {
					flag_tss = 1;
					break;
				}					
			}
			break;
		}
		case 2:{
			while(nodeSet[cnode].isleaf != 1){   //find matched leaf nodes: cnode
				numbit -= nodeSet[cnode].numbit[1];
				cchild = (delete_rule.range[1][0]>>numbit) & nodeSet[cnode].andbit[1];
				cnode = nodeSet[cnode].child[cchild];   
				queryCount[0]++;
				
				if(cnode == Null) break;
				if(nodeSet[cnode].flag == 2 && nodeSet[cnode].isleaf != 1) {
					flag_tss = 1;
					break;
				}					
			}
			break;
			
		}
		case 3:{
			while(nodeSet[cnode].isleaf != 1){    //find matched leaf nodes: cnode
				numbit1 -= nodeSet[cnode].numbit[0];
				numbit2 -= nodeSet[cnode].numbit[1];
				cchild = ((delete_rule.range[0][0]>>numbit1) & ANDBITS2)*nodeSet[cnode].ncuts[1] + ((delete_rule.range[1][0]>>numbit2) & ANDBITS2);
				cnode = nodeSet[cnode].child[cchild];  
				queryCount[0]++;
				if(cnode == Null) break;
				if(nodeSet[cnode].flag == 2 && nodeSet[cnode].isleaf != 1) {
					flag_tss = 1;
					break;
				}							
			}
			break;		

		}
		default: break;
			
	}
	
	if(cnode == Null){
		printf("the node is empty, delete failed! rule id=%d\n",delete_rule.id);
	}
	else if(cnode != Null && flag_tss == 1){
		nodeSet[cnode].PSTSS.DeleteRule(delete_rule);
	}
	else if(cnode != Null && flag_tss == 0 && nodeSet[cnode].isleaf == 1){

		if(nodeSet[cnode].nrules > 0){
			for(i=0;i<nodeSet[cnode].classifier.size();i++){
				if(nodeSet[cnode].classifier[i].id == delete_rule.id) break;
			}
			for(j=i;j<(nodeSet[cnode].classifier.size()-1);j++){
				nodeSet[cnode].classifier[j]=nodeSet[cnode].classifier[j+1];
			}
			nodeSet[cnode].classifier.pop_back();
			nodeSet[cnode].nrules--;
		}
	}
}

void CutTSS::InsertRule(const Rule& insert_rule) {
	int cchild;
	int flag_tss = 0;
	int v = 1,u;
	unsigned int numbit = 32;
	unsigned int numbit1 = 32;
	unsigned int numbit2 = 32;

	switch(speedUpFlag) // speedUpFlag=3:sa&da,1:sa, 2:da, others:for !5-tuple rules
	{		
		case 1:{
			while(nodeSet[v].isleaf != 1){   //find matched leaf nodes: cnode
				numbit -= nodeSet[v].numbit[0];
				cchild = (insert_rule.range[0][0]>>numbit) & ANDBITS1;	
				u = nodeSet[v].child[cchild];   
				queryCount[0]++;
				
				if(u == Null) break;
				if(nodeSet[u].flag == 2 && nodeSet[u].isleaf != 1) {
					flag_tss = 1;
					break;
				}	
				v = u;
			}
			break;
		}
		case 2:{
			while(nodeSet[v].isleaf != 1){   //find matched leaf nodes: cnode
				numbit -= nodeSet[v].numbit[1];
				cchild = (insert_rule.range[1][0]>>numbit) & ANDBITS1;
				u = nodeSet[v].child[cchild];   
				queryCount[0]++;
				
				if(u == Null) break;
				if(nodeSet[u].flag == 2 && nodeSet[u].isleaf != 1) {
					flag_tss = 1;
					break;
				}
				v = u;
			}
			break;
			
		}
		case 3:{
			while(nodeSet[v].isleaf != 1){    //find matched leaf nodes: cnode
				numbit1 -= nodeSet[v].numbit[0];
				numbit2 -= nodeSet[v].numbit[1];
				cchild = ((insert_rule.range[0][0]>>numbit1) & ANDBITS2)*nodeSet[v].ncuts[1] + ((insert_rule.range[1][0]>>numbit2) & ANDBITS2);
				u = nodeSet[v].child[cchild];   
				queryCount[0]++;
				if(u == Null) break;
				if(nodeSet[u].flag == 2 && nodeSet[u].isleaf != 1) {
					flag_tss = 1;
					break;
				}	
				v = u;
			}
			break;		

		}
		default: break;
			
	}	
	
	if(u == Null){
        printf("the node is empty, create a new node! rule id=%d\n",insert_rule.id);

		nodeSet[v].child[cchild] = freelist;
		u=freelist;
		freelist++; 
		nodeSet[u].nrules = 1;
		nodeSet[u].classifier.push_back(insert_rule);
		nodeSet[u].flag = 1;
		nodeSet[u].isleaf = 1;

	}
	else if(u != Null && flag_tss == 1){
		nodeSet[u].PSTSS.InsertRule(insert_rule);
	}
	else if(u != Null && flag_tss == 0 && nodeSet[u].isleaf == 1){
		nodeSet[u].nrules++;
		nodeSet[u].classifier.push_back(insert_rule);

	}

}

